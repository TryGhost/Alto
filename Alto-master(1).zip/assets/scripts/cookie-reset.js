document.getElementById("Cookie settings").addEventListener("click", cookieConsentReset);

function cookieConsentReset(){
  cookieConsent.reset();
}