if (localStorage.getItem('alto_dark') == 'true') {
	document.documentElement.classList.add('dark-mode');
}